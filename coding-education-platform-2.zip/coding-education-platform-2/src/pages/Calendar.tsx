import { useEffect, useState } from "react"
import { getEvents } from "../services/firestoreService"
import EventCalendar from "../components/EventCalendar"

const Calendar = () => {
  const [events, setEvents] = useState([])

  useEffect(() => {
    const fetchEvents = async () => {
      const eventsData = await getEvents()
      setEvents(eventsData)
    }

    fetchEvents()
  }, [])

  return (
    <div className="calendar">
      <h1>Calendar</h1>
      <EventCalendar events={events} />
    </div>
  )
}

export default Calendar

