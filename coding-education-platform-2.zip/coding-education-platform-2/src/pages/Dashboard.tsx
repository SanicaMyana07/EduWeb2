import { useEffect, useState } from "react"
import styled from "styled-components"
import { useAuth } from "../contexts/AuthContext"
import { getUserData } from "../services/firestoreService"
import { getUserLeetCodeInfo } from "../services/leetCodeService"
import UserProfile from "../components/UserProfile"
import RecentActivity from "../components/RecentActivity"
import UpcomingEvents from "../components/UpcomingEvents"

const DashboardContainer = styled.div`
  max-width: 1200px;
  margin: 2rem auto;
  padding: 0 1rem;
`

const DashboardHeader = styled.h1`
  color: var(--color-primary);
  margin-bottom: 2rem;
`

const DashboardGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`

const Dashboard = () => {
  const { currentUser } = useAuth()
  const [userData, setUserData] = useState(null)
  const [leetCodeInfo, setLeetCodeInfo] = useState(null)

  useEffect(() => {
    const fetchData = async () => {
      if (currentUser) {
        const userDataFromFirestore = await getUserData(currentUser.uid)
        setUserData(userDataFromFirestore)

        const leetCodeData = await getUserLeetCodeInfo(userDataFromFirestore.leetCodeUsername)
        setLeetCodeInfo(leetCodeData)
      }
    }

    fetchData()
  }, [currentUser])

  return (
    <DashboardContainer>
      <DashboardHeader>Dashboard</DashboardHeader>
      {userData && leetCodeInfo && (
        <DashboardGrid>
          <UserProfile userData={userData} leetCodeInfo={leetCodeInfo} />
          <RecentActivity activities={userData.recentActivities} />
          <UpcomingEvents events={userData.upcomingEvents} />
        </DashboardGrid>
      )}
    </DashboardContainer>
  )
}

export default Dashboard

