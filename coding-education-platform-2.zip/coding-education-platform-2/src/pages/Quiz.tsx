import { useEffect, useState } from "react"
import { getQuizzes } from "../services/firestoreService"
import QuizList from "../components/QuizList"
import QuizDetails from "../components/QuizDetails"

const Quiz = () => {
  const [quizzes, setQuizzes] = useState([])
  const [selectedQuiz, setSelectedQuiz] = useState(null)

  useEffect(() => {
    const fetchQuizzes = async () => {
      const quizzesData = await getQuizzes()
      setQuizzes(quizzesData)
    }

    fetchQuizzes()
  }, [])

  return (
    <div className="quiz">
      <h1>Quizzes</h1>
      {selectedQuiz ? (
        <QuizDetails quiz={selectedQuiz} onBack={() => setSelectedQuiz(null)} />
      ) : (
        <QuizList quizzes={quizzes} onSelectQuiz={setSelectedQuiz} />
      )}
    </div>
  )
}

export default Quiz

