import styled from "styled-components"

const ActivityCard = styled.div`
  background-color: var(--color-white);
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`

const ActivityHeader = styled.h3`
  color: var(--color-primary);
  margin-top: 0;
  margin-bottom: 1rem;
`

const ActivityList = styled.ul`
  list-style-type: none;
  padding: 0;
  margin: 0;
`

const ActivityItem = styled.li`
  display: flex;
  align-items: center;
  padding: 0.75rem 0;
  border-bottom: 1px solid var(--color-background);

  &:last-child {
    border-bottom: none;
  }
`

const ActivityIcon = styled.span`
  margin-right: 1rem;
  font-size: 1.25rem;
  color: var(--color-accent);
`

const ActivityContent = styled.div`
  flex: 1;
`

const ActivityTitle = styled.div`
  font-weight: 500;
`

const ActivityTime = styled.div`
  font-size: 0.875rem;
  color: var(--color-text-light);
`

const RecentActivity = ({ activities }) => {
  return (
    <ActivityCard>
      <ActivityHeader>Recent Activity</ActivityHeader>
      <ActivityList>
        {activities.map((activity, index) => (
          <ActivityItem key={index}>
            <ActivityIcon>{activity.icon}</ActivityIcon>
            <ActivityContent>
              <ActivityTitle>{activity.title}</ActivityTitle>
              <ActivityTime>{activity.time}</ActivityTime>
            </ActivityContent>
          </ActivityItem>
        ))}
      </ActivityList>
    </ActivityCard>
  )
}

export default RecentActivity

