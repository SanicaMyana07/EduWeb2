import { useState } from "react"
import { useAuth } from "../contexts/AuthContext"
import { sendIssueToWhatsApp } from "../services/whatsappService"

const IssueReporter = ({ section }) => {
  const [issue, setIssue] = useState("")
  const { currentUser } = useAuth()

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (issue.trim()) {
      await sendIssueToWhatsApp(currentUser.uid, issue, section)
      setIssue("")
      alert("Your issue has been reported successfully!")
    }
  }

  return (
    <div className="issue-reporter">
      <h3>Report an Issue</h3>
      <form onSubmit={handleSubmit}>
        <textarea
          value={issue}
          onChange={(e) => setIssue(e.target.value)}
          placeholder="Describe your issue here..."
          rows={4}
        />
        <button type="submit">Submit Issue</button>
      </form>
    </div>
  )
}

export default IssueReporter

