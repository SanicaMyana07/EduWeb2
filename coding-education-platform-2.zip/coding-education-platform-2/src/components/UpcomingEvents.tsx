import styled from "styled-components"

const EventsCard = styled.div`
  background-color: var(--color-white);
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`

const EventsHeader = styled.h3`
  color: var(--color-primary);
  margin-top: 0;
  margin-bottom: 1rem;
`

const EventList = styled.ul`
  list-style-type: none;
  padding: 0;
  margin: 0;
`

const EventItem = styled.li`
  display: flex;
  align-items: center;
  padding: 0.75rem 0;
  border-bottom: 1px solid var(--color-background);

  &:last-child {
    border-bottom: none;
  }
`

const EventDate = styled.div`
  background-color: var(--color-accent);
  color: var(--color-white);
  border-radius: 4px;
  padding: 0.5rem;
  text-align: center;
  margin-right: 1rem;
  min-width: 60px;
`

const EventDay = styled.div`
  font-size: 1.25rem;
  font-weight: bold;
`

const EventMonth = styled.div`
  font-size: 0.875rem;
`

const EventContent = styled.div`
  flex: 1;
`

const EventTitle = styled.div`
  font-weight: 500;
`

const EventTime = styled.div`
  font-size: 0.875rem;
  color: var(--color-text-light);
`

const UpcomingEvents = ({ events }) => {
  return (
    <EventsCard>
      <EventsHeader>Upcoming Events</EventsHeader>
      <EventList>
        {events.map((event, index) => (
          <EventItem key={index}>
            <EventDate>
              <EventDay>{event.day}</EventDay>
              <EventMonth>{event.month}</EventMonth>
            </EventDate>
            <EventContent>
              <EventTitle>{event.title}</EventTitle>
              <EventTime>{event.time}</EventTime>
            </EventContent>
          </EventItem>
        ))}
      </EventList>
    </EventsCard>
  )
}

export default UpcomingEvents

