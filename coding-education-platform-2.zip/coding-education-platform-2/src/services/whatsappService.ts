import axios from "axios"

const WHATSAPP_API_URL = "YOUR_WHATSAPP_API_ENDPOINT"

export const sendIssueToWhatsApp = async (userId, issue, section) => {
  try {
    const response = await axios.post(WHATSAPP_API_URL, {
      userId,
      issue,
      section,
    })
    return response.data
  } catch (error) {
    console.error("Error sending issue to WhatsApp:", error)
    return null
  }
}

